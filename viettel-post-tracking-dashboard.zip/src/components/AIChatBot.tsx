import { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { ChatMessage } from '../types';
import {
  Send,
  Sparkles,
  Bot,
  User,
  Trash2,
  HelpCircle,
  TrendingUp,
  MessageSquareQuote
} from 'lucide-react';

interface AIChatBotProps {
  onSendMessage: (messages: ChatMessage[]) => Promise<string>;
}

export default function AIChatBot({ onSendMessage }: AIChatBotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      content: 'Xin chào! Tôi là Trợ lý Ảo Viettel Post AI. Tôi đã đồng bộ dữ liệu bưu cục thời gian thực của bạn. Tôi có thể giúp bạn tổng hợp doanh số COD, tra cứu lịch trình bưu tá, hoặc viết các mẫu kịch bản thông báo Zalo/Facebook cực kỳ nhanh chóng. Bạn muốn hỏi gì hôm nay?',
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = [
    '📋 Thống kê nhanh đơn bưu cục',
    '💰 Đơn hàng có COD cao nhất?',
    '📝 Soạn tin Zalo cho khách VTP982415632',
    '🚚 Có đơn nào đang bị hoàn không?'
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text) return;

    if (!textToSend) setInput('');

    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setSending(true);

    try {
      const response = await onSendMessage(newMessages);
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          role: 'model',
          content: response,
          timestamp: new Date().toISOString(),
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          role: 'model',
          content: 'Xin lỗi, tôi gặp sự cố kết nối tới máy chủ AI. Bạn hãy kiểm tra lại kết nối mạng nhé.',
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setSending(false);
    }
  };

  const handleClearChat = () => {
    if (!confirm('Bạn có chắc chắn muốn xóa lịch sử trò chuyện?')) return;
    setMessages([
      {
        id: 'welcome',
        role: 'model',
        content: 'Cuộc hội thoại đã được đặt lại. Tôi có thể hỗ trợ gì tiếp theo cho bưu cục của bạn?',
        timestamp: new Date().toISOString(),
      },
    ]);
  };

  return (
    <div id="ai-chatbot-panel" className="bg-white border border-zinc-200/80 rounded-2xl shadow-xs overflow-hidden h-[600px] flex flex-col">
      {/* Bot Header */}
      <div className="p-4 bg-indigo-600 text-white flex items-center justify-between shadow-sm shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="p-1.5 bg-white/10 rounded-lg">
            <Sparkles className="w-5 h-5 text-indigo-200 animate-pulse" />
          </div>
          <div>
            <h4 className="font-semibold text-xs text-white">Viettel Post AI Assistant</h4>
            <span className="text-[10px] text-indigo-200 flex items-center">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full mr-1.5 animate-pulse" />
              Đồng bộ bưu cục • Live
            </span>
          </div>
        </div>
        <button
          id="clear-chat-history-btn"
          onClick={handleClearChat}
          title="Xóa cuộc trò chuyện"
          className="p-1.5 hover:bg-white/10 rounded-lg text-indigo-200 hover:text-white transition-colors"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div id="chatbot-messages-scroll-area" className="flex-1 p-4 overflow-y-auto bg-zinc-50/50 space-y-4">
        {messages.map((m) => {
          const isBot = m.role === 'model';
          return (
            <div
              id={`chat-msg-${m.id}`}
              key={m.id}
              className={`flex items-start space-x-2.5 max-w-[85%] ${isBot ? '' : 'ml-auto flex-row-reverse space-x-reverse'}`}
            >
              <div className={`p-1.5 rounded-lg shrink-0 ${isBot ? 'bg-indigo-50 text-indigo-600' : 'bg-zinc-200 text-zinc-700'}`}>
                {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>
              <div className={`p-3 rounded-2xl text-xs leading-relaxed shadow-xs ${isBot ? 'bg-white border border-zinc-150 text-zinc-800' : 'bg-indigo-600 text-white'}`}>
                {/* Format simple newlines */}
                <div className="whitespace-pre-wrap">{m.content}</div>
                <span className={`text-[9px] block mt-1.5 text-right ${isBot ? 'text-zinc-400' : 'text-indigo-200'}`}>
                  {new Date(m.timestamp).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          );
        })}
        {sending && (
          <div className="flex items-start space-x-2.5 max-w-[80%]">
            <div className="p-1.5 rounded-lg shrink-0 bg-indigo-50 text-indigo-600">
              <Bot className="w-4 h-4 animate-bounce" />
            </div>
            <div className="p-3 rounded-2xl text-xs bg-white border border-zinc-150 text-zinc-400 flex items-center space-x-1.5 shadow-xs">
              <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce" />
              <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.2s]" />
              <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.4s]" />
              <span className="pl-1">Trợ lý PostAI đang phân tích dữ liệu...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Suggestions */}
      <div id="chatbot-quick-prompts-row" className="p-2 border-t border-zinc-100 bg-white shrink-0 overflow-x-auto flex space-x-1.5 scrollbar-thin">
        {quickPrompts.map((p, idx) => (
          <button
            id={`quick-prompt-${idx}`}
            key={idx}
            onClick={() => handleSend(p.replace(/^[^\s]+\s/, ''))} // strip emoji if desired, or send full string
            disabled={sending}
            className="text-[10px] font-semibold text-zinc-600 hover:text-indigo-600 hover:border-indigo-300 border border-zinc-200 rounded-full px-3 py-1 bg-zinc-50 hover:bg-indigo-50/35 transition-all whitespace-nowrap shrink-0"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Input Form */}
      <div id="chatbot-input-footer" className="p-3 bg-white border-t border-zinc-150 flex items-center space-x-2 shrink-0">
        <input
          id="chatbot-input-field"
          type="text"
          placeholder="Hỏi về doanh số, đơn hàng, soạn tin Zalo..."
          className="flex-1 px-4 py-2 border border-zinc-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-zinc-800 placeholder-zinc-400"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          disabled={sending}
        />
        <button
          id="send-chat-msg-btn"
          onClick={() => handleSend()}
          disabled={sending || !input.trim()}
          className="p-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-zinc-200 text-white rounded-xl transition-colors shrink-0 shadow-xs"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
