import { useMemo } from 'react';
import { motion } from 'motion/react';
import { Order, OrderStatus } from '../types';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  AreaChart,
  Area,
} from 'recharts';
import {
  TrendingUp,
  Package,
  Truck,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Coins,
  Receipt,
  ShoppingBag
} from 'lucide-react';

interface StatsDashboardProps {
  orders: Order[];
}

export default function StatsDashboard({ orders }: StatsDashboardProps) {
  // Compute Stats
  const stats = useMemo(() => {
    const total = orders.length;
    const pending = orders.filter((o) => o.status === 'pending').length;
    const picked = orders.filter((o) => o.status === 'picked').length;
    const shipping = orders.filter((o) => o.status === 'shipping').length;
    const delivered = orders.filter((o) => o.status === 'delivered').length;
    const returned = orders.filter((o) => o.status === 'returned').length;
    const cancelled = orders.filter((o) => o.status === 'cancelled').length;

    const totalCOD = orders.reduce((sum, o) => sum + o.codAmount, 0);
    const totalShippingFee = orders.reduce((sum, o) => sum + o.shippingFee, 0);

    // Success rate: Delivered / (Delivered + Returned)
    const closedCompleted = delivered + returned;
    const successRate = closedCompleted > 0 ? Math.round((delivered / closedCompleted) * 100) : 100;

    return {
      total,
      pending,
      picked,
      shipping,
      delivered,
      returned,
      cancelled,
      totalCOD,
      totalShippingFee,
      successRate,
    };
  }, [orders]);

  // Status Distribution Data for Pie Chart
  const pieData = [
    { name: 'Chờ lấy', value: stats.pending, color: '#f59e0b' }, // Amber
    { name: 'Đã gom', value: stats.picked, color: '#6366f1' },   // Indigo
    { name: 'Đang giao', value: stats.shipping, color: '#3b82f6' }, // Blue
    { name: 'Đã giao', value: stats.delivered, color: '#10b981' },  // Green
    { name: 'Chuyển hoàn', value: stats.returned, color: '#ec4899' }, // Pink
    { name: 'Đã hủy', value: stats.cancelled, color: '#ef4444' },    // Red
  ].filter((item) => item.value > 0);

  // Region / Province delivery distribution (simulated by parsing address)
  const regionData = useMemo(() => {
    const counts: Record<string, { name: string; cod: number; count: number }> = {};
    orders.forEach((o) => {
      let region = 'Khác';
      if (o.receiverAddress.includes('Hồ Chí Minh') || o.receiverAddress.includes('TP. HCM') || o.receiverAddress.includes('TP.HCM') || o.receiverAddress.includes('Q1') || o.receiverAddress.includes('Quận 1')) {
        region = 'TP. HCM';
      } else if (o.receiverAddress.includes('Hà Nội')) {
        region = 'Hà Nội';
      } else if (o.receiverAddress.includes('Đà Nẵng')) {
        region = 'Đà Nẵng';
      } else if (o.receiverAddress.includes('Cần Thơ')) {
        region = 'Cần Thơ';
      } else if (o.receiverAddress.includes('Đồng Nai')) {
        region = 'Đồng Nai';
      } else if (o.receiverAddress.includes('Hải Phòng')) {
        region = 'Hải Phòng';
      }

      if (!counts[region]) {
        counts[region] = { name: region, cod: 0, count: 0 };
      }
      counts[region].count += 1;
      counts[region].cod += o.codAmount;
    });

    return Object.values(counts).sort((a, b) => b.count - a.count);
  }, [orders]);

  // Card stats config
  const cards = [
    {
      id: 'stat-total',
      title: 'Tổng số đơn hàng',
      value: stats.total,
      icon: Package,
      color: 'bg-zinc-100 text-zinc-800 border-zinc-200/60',
      desc: 'Toàn bộ vận đơn',
    },
    {
      id: 'stat-shipping',
      title: 'Đang giao hàng',
      value: stats.shipping,
      icon: Truck,
      color: 'bg-blue-50 text-blue-700 border-blue-200/50',
      desc: 'Bưu tá đang phát',
    },
    {
      id: 'stat-delivered',
      title: 'Đã giao thành công',
      value: stats.delivered,
      icon: CheckCircle2,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200/50',
      desc: 'Đã thu tiền ký nhận',
    },
    {
      id: 'stat-success-rate',
      title: 'Tỉ lệ giao thành công',
      value: `${stats.successRate}%`,
      icon: TrendingUp,
      color: 'bg-violet-50 text-violet-700 border-violet-200/50',
      desc: 'Trừ đơn đã hủy',
    },
    {
      id: 'stat-total-cod',
      title: 'Tổng tiền thu hộ COD',
      value: `${stats.totalCOD.toLocaleString('vi-VN')} đ`,
      icon: Coins,
      color: 'bg-amber-50 text-amber-700 border-amber-200/50',
      desc: 'Tiền COD của khách',
    },
    {
      id: 'stat-shipping-fee',
      title: 'Tổng cước phí vận chuyển',
      value: `${stats.totalShippingFee.toLocaleString('vi-VN')} đ`,
      icon: Receipt,
      color: 'bg-indigo-50 text-indigo-700 border-indigo-200/50',
      desc: 'Ước tính phí Viettel Post',
    },
  ];

  return (
    <div id="stats-dashboard-container" className="space-y-6">
      {/* Cards Grid */}
      <div id="kpi-cards-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {cards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <motion.div
              id={`card-${card.id}`}
              key={card.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.05 }}
              className={`p-5 rounded-2xl border ${card.color} flex items-start justify-between shadow-xs hover:shadow-md transition-all duration-300`}
            >
              <div className="space-y-2">
                <span className="text-xs font-medium uppercase tracking-wider opacity-80">{card.title}</span>
                <h3 className="text-2xl font-bold tracking-tight">{card.value}</h3>
                <p className="text-xs opacity-75">{card.desc}</p>
              </div>
              <div className="p-3 rounded-xl bg-white/75 shadow-xs border border-black/5">
                <Icon className="w-5 h-5 stroke-[1.8]" />
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Charts section */}
      <div id="charts-grid" className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Pie Chart - Status breakdown */}
        <motion.div
          id="status-pie-chart-card"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="lg:col-span-2 p-5 bg-white border border-zinc-200/80 shadow-xs rounded-2xl flex flex-col"
        >
          <div className="flex items-center justify-between mb-4 border-b border-zinc-100 pb-3">
            <div>
              <h4 className="text-sm font-semibold text-zinc-900">Trạng Thái Đơn Hàng</h4>
              <p className="text-xs text-zinc-500">Phân chia tỷ lệ vận đơn bưu cục</p>
            </div>
            <span className="text-xs bg-zinc-100 text-zinc-600 px-2.5 py-1 rounded-full font-medium">Viettel Post</span>
          </div>

          <div id="pie-chart-wrapper" className="h-56 relative flex items-center justify-center">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: any) => [`${value} đơn hàng`, 'Số lượng']}
                    contentStyle={{ borderRadius: '8px', border: '1px solid #e4e4e7' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-zinc-400 text-xs text-center py-10">Chưa có dữ liệu thống kê trạng thái</div>
            )}
          </div>

          {/* Legend Grid */}
          <div id="pie-legend-grid" className="grid grid-cols-2 gap-2.5 mt-auto pt-3 border-t border-zinc-50 text-xs">
            {pieData.map((item, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                <span className="text-zinc-600 truncate">{item.name}</span>
                <span className="font-semibold text-zinc-800 ml-auto">{item.value}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Bar/Area Chart - Geographical Distribution & COD */}
        <motion.div
          id="geo-cod-chart-card"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="lg:col-span-3 p-5 bg-white border border-zinc-200/80 shadow-xs rounded-2xl flex flex-col"
        >
          <div className="flex items-center justify-between mb-4 border-b border-zinc-100 pb-3">
            <div>
              <h4 className="text-sm font-semibold text-zinc-900">Phân Phối Theo Tỉnh Thành</h4>
              <p className="text-xs text-zinc-500">Thống kê số lượng đơn hàng và giá trị COD thu hộ</p>
            </div>
            <span className="text-xs bg-indigo-50 text-indigo-600 px-2.5 py-1 rounded-full font-medium">Khu vực phát</span>
          </div>

          <div id="geo-bar-chart-wrapper" className="h-64 mt-2">
            {regionData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={regionData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <XAxis dataKey="name" stroke="#71717a" fontSize={11} tickLine={false} />
                  <YAxis yAxisId="left" stroke="#71717a" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis yAxisId="right" orientation="right" stroke="#71717a" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(tick) => `${tick / 1000}k`} />
                  <Tooltip
                    contentStyle={{ borderRadius: '8px', border: '1px solid #e4e4e7' }}
                    formatter={(value: any, name: string) => {
                      if (name === 'COD (đ)') return [`${value.toLocaleString('vi-VN')} đ`, 'Tổng Tiền COD'];
                      return [`${value} đơn`, 'Số Đơn Hàng'];
                    }}
                  />
                  <Legend verticalAlign="top" height={36} iconSize={10} iconType="circle" wrapperStyle={{ fontSize: '11px' }} />
                  <Bar yAxisId="left" dataKey="count" name="Số Đơn Hàng" fill="#4f46e5" radius={[4, 4, 0, 0]} maxBarSize={30} />
                  <Bar yAxisId="right" dataKey="cod" name="COD (đ)" fill="#f59e0b" radius={[4, 4, 0, 0]} maxBarSize={30} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-zinc-400 text-xs text-center py-16">Chưa có dữ liệu phân vùng</div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Extra helper alerts section */}
      <div id="dashboard-status-banner" className="bg-zinc-50 border border-zinc-200/60 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-zinc-200/70 rounded-xl text-zinc-700">
            <ShoppingBag className="w-5 h-5" />
          </div>
          <div>
            <h5 className="text-xs font-semibold text-zinc-900">Vận hành đồng bộ thời gian thực</h5>
            <p className="text-[11px] text-zinc-500">Mọi thay đổi bưu cục và trạng thái giao nhận đều được đồng bộ tức thì với bộ công cụ thông báo Zalo/Facebook.</p>
          </div>
        </div>
        <div className="hidden sm:flex space-x-2 text-xs font-medium">
          <span className="flex items-center text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-1.5 animate-pulse" />
            Zalo API Online
          </span>
          <span className="flex items-center text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full">
            <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-1.5 animate-pulse" />
            Facebook API Online
          </span>
        </div>
      </div>
    </div>
  );
}
