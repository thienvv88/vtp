import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Order, OrderStatus } from '../types';
import {
  Search,
  Plus,
  Trash2,
  Play,
  MessageSquare,
  Sparkles,
  ExternalLink,
  ChevronRight,
  MapPin,
  Calendar,
  X,
  FileText,
  User,
  Phone,
  DollarSign,
  Scale,
  Send,
  AlertCircle,
  HelpCircle,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';

interface OrderListProps {
  orders: Order[];
  onAddOrder: (orderData: any) => Promise<void>;
  onDeleteOrder: (id: string) => Promise<void>;
  onSimulateOrder: (id: string) => Promise<void>;
  onUpdateOrder: (id: string, updateData: any) => Promise<void>;
  onDraftNotification: (orderId: string, channel: 'zalo' | 'facebook') => Promise<string>;
  onSendNotification: (orderId: string, channel: 'zalo' | 'facebook', recipient: string, message: string) => Promise<any>;
  onSyncViettelPost?: () => Promise<void>;
  syncingVTP?: boolean;
}

export default function OrderList({
  orders,
  onAddOrder,
  onDeleteOrder,
  onSimulateOrder,
  onUpdateOrder,
  onDraftNotification,
  onSendNotification,
  onSyncViettelPost,
  syncingVTP = false,
}: OrderListProps) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState<string | null>(null);

  // Form State
  const [receiverName, setReceiverName] = useState('');
  const [receiverPhone, setReceiverPhone] = useState('');
  const [receiverAddress, setReceiverAddress] = useState('');
  const [codAmount, setCodAmount] = useState('350000');
  const [shippingFee, setShippingFee] = useState('30000');
  const [weight, setWeight] = useState('500');
  const [notes, setNotes] = useState('');

  // Notification Modal State
  const [activeNotifyModal, setActiveNotifyModal] = useState<{
    order: Order;
    channel: 'zalo' | 'facebook';
  } | null>(null);
  const [notifyDraft, setNotifyDraft] = useState('');
  const [draftingAI, setDraftingAI] = useState(false);
  const [sendResult, setSendResult] = useState<any | null>(null);
  const [personalZaloCopied, setPersonalZaloCopied] = useState(false);

  // Status mapping
  const statusConfig: Record<OrderStatus, { text: string; color: string; bg: string; dot: string }> = {
    pending: { text: 'Chờ lấy hàng', color: 'text-amber-700 border-amber-200', bg: 'bg-amber-50', dot: 'bg-amber-500' },
    picked: { text: 'Đã gom hàng', color: 'text-indigo-700 border-indigo-200', bg: 'bg-indigo-50', dot: 'bg-indigo-500' },
    shipping: { text: 'Đang giao hàng', color: 'text-blue-700 border-blue-200', bg: 'bg-blue-50', dot: 'bg-blue-500' },
    delivered: { text: 'Đã giao thành công', color: 'text-emerald-700 border-emerald-200', bg: 'bg-emerald-50', dot: 'bg-emerald-500' },
    returned: { text: 'Chuyển hoàn', color: 'text-pink-700 border-pink-200', bg: 'bg-pink-50', dot: 'bg-pink-500' },
    cancelled: { text: 'Đã hủy', color: 'text-red-700 border-red-200', bg: 'bg-red-50', dot: 'bg-red-500' },
  };

  // Filter logic
  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.receiverName.toLowerCase().includes(search.toLowerCase()) ||
      o.receiverPhone.includes(search);
    const matchesStatus = statusFilter === 'all' || o.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!receiverName || !receiverPhone || !receiverAddress) {
      alert('Vui lòng điền đầy đủ Tên, SĐT và Địa chỉ người nhận.');
      return;
    }

    setLoading('create');
    try {
      await onAddOrder({
        receiverName,
        receiverPhone,
        receiverAddress,
        codAmount: parseInt(codAmount) || 0,
        shippingFee: parseInt(shippingFee) || 0,
        weight: parseInt(weight) || 0,
        notes,
      });

      // Reset form
      setReceiverName('');
      setReceiverPhone('');
      setReceiverAddress('');
      setCodAmount('250000');
      setShippingFee('30000');
      setWeight('350');
      setNotes('');
      setShowAddForm(false);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(null);
    }
  };

  const handleSimulate = async (orderId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLoading(`simulate-${orderId}`);
    try {
      await onSimulateOrder(orderId);
      // Update selected order view details if active
      if (selectedOrder && selectedOrder.id === orderId) {
        const updated = orders.find(o => o.id === orderId);
        if (updated) setSelectedOrder(updated);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(null);
    }
  };

  const handleDelete = async (orderId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Bạn có chắc chắn muốn xóa đơn hàng này?')) return;
    setLoading(`delete-${orderId}`);
    try {
      await onDeleteOrder(orderId);
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(null);
    }
  };

  const handleOpenNotificationModal = async (order: Order, channel: 'zalo' | 'facebook', e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveNotifyModal({ order, channel });
    setNotifyDraft('');
    setSendResult(null);
    setDraftingAI(true);

    try {
      const draft = await onDraftNotification(order.id, channel);
      setNotifyDraft(draft);
    } catch (err) {
      setNotifyDraft('Xin lỗi, không thể khởi tạo nội dung tin nhắn mẫu.');
    } finally {
      setDraftingAI(false);
    }
  };

  const handleSendNotification = async () => {
    if (!activeNotifyModal) return;
    setLoading('send-notification');
    try {
      const result = await onSendNotification(
        activeNotifyModal.order.id,
        activeNotifyModal.channel,
        `${activeNotifyModal.order.receiverName} (${activeNotifyModal.order.receiverPhone})`,
        notifyDraft
      );
      setSendResult(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(null);
    }
  };

  const handleSendViaPersonalZalo = () => {
    if (!activeNotifyModal) return;
    const phone = activeNotifyModal.order.receiverPhone.replace(/\D/g, '');
    navigator.clipboard.writeText(notifyDraft)
      .then(() => {
        setPersonalZaloCopied(true);
        setTimeout(() => setPersonalZaloCopied(false), 8000);
        window.open(`https://zalo.me/${phone}`, '_blank');
      })
      .catch((err) => {
        console.error('Clipboard copy failed: ', err);
        window.open(`https://zalo.me/${phone}`, '_blank');
      });
  };

  return (
    <div id="order-list-section" className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      {/* List Panel */}
      <div id="order-main-list-column" className="xl:col-span-2 space-y-4">
        {/* Search, Filter & Action Row */}
        <div id="filter-actions-bar" className="bg-white p-4 rounded-2xl border border-zinc-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="search-orders-input"
              type="text"
              placeholder="Tìm theo mã vận đơn, tên khách, sđt..."
              className="w-full pl-9 pr-4 py-2 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 placeholder-zinc-400"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div id="filter-wrapper" className="flex items-center space-x-2 shrink-0 overflow-x-auto pb-1 md:pb-0">
            <select
              id="status-select-filter"
              className="px-3 py-2 border border-zinc-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-zinc-700 bg-white"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="pending">Chờ lấy hàng</option>
              <option value="picked">Đã gom hàng</option>
              <option value="shipping">Đang giao hàng</option>
              <option value="delivered">Đã giao thành công</option>
              <option value="returned">Chuyển hoàn</option>
              <option value="cancelled">Đã hủy</option>
            </select>

            {onSyncViettelPost && (
              <button
                id="order-list-vtp-sync-btn"
                onClick={onSyncViettelPost}
                disabled={syncingVTP}
                className="flex items-center space-x-1.5 px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs rounded-xl border border-red-200 transition-colors duration-200 whitespace-nowrap"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncingVTP ? 'animate-spin' : ''}`} />
                <span>{syncingVTP ? 'Đang đồng bộ...' : 'Đồng bộ VTPost'}</span>
              </button>
            )}

            <button
              id="toggle-add-order-form-btn"
              onClick={() => setShowAddForm(!showAddForm)}
              className="flex items-center space-x-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors duration-200 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tạo vận đơn</span>
            </button>
          </div>
        </div>

        {/* Create Order Drawer/Form */}
        <AnimatePresence>
          {showAddForm && (
            <motion.div
              id="add-order-form-card"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-white border border-indigo-100 rounded-2xl overflow-hidden shadow-xs"
            >
              <form onSubmit={handleCreateOrder} className="p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-700">Tạo vận đơn Viettel Post mới</span>
                  <button
                    id="close-add-form-btn"
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="p-1 hover:bg-zinc-100 rounded-lg text-zinc-400"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-zinc-600 uppercase">Họ và tên người nhận</label>
                    <input
                      id="input-receiver-name"
                      type="text"
                      required
                      placeholder="Nguyễn Văn A"
                      className="w-full px-3 py-2 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                      value={receiverName}
                      onChange={(e) => setReceiverName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-zinc-600 uppercase">Số điện thoại nhận</label>
                    <input
                      id="input-receiver-phone"
                      type="text"
                      required
                      placeholder="0987654321"
                      className="w-full px-3 py-2 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                      value={receiverPhone}
                      onChange={(e) => setReceiverPhone(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-600 uppercase">Địa chỉ chi tiết người nhận</label>
                  <input
                    id="input-receiver-address"
                    type="text"
                    required
                    placeholder="Số 10 Lê Duẩn, Quận 1, TP. Hồ Chí Minh"
                    className="w-full px-3 py-2 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    value={receiverAddress}
                    onChange={(e) => setReceiverAddress(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-zinc-600 uppercase">Tiền COD thu hộ (đ)</label>
                    <input
                      id="input-cod-amount"
                      type="number"
                      placeholder="350000"
                      className="w-full px-3 py-2 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                      value={codAmount}
                      onChange={(e) => setCodAmount(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-zinc-600 uppercase">Cước vận chuyển (đ)</label>
                    <input
                      id="input-shipping-fee"
                      type="number"
                      placeholder="30000"
                      className="w-full px-3 py-2 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                      value={shippingFee}
                      onChange={(e) => setShippingFee(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-zinc-600 uppercase">Trọng lượng (grams)</label>
                    <input
                      id="input-weight"
                      type="number"
                      placeholder="500"
                      className="w-full px-3 py-2 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-600 uppercase">Ghi chú bưu tá</label>
                  <textarea
                    id="input-notes"
                    placeholder="Giao hàng buổi chiều, cho khách đồng kiểm size"
                    rows={2}
                    className="w-full px-3 py-2 border border-zinc-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 resize-none"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-2 border-t border-zinc-100">
                  <button
                    id="cancel-form-btn"
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="px-4 py-2 border border-zinc-200 rounded-xl text-xs font-semibold text-zinc-600 hover:bg-zinc-50 transition-colors"
                  >
                    Hủy bỏ
                  </button>
                  <button
                    id="submit-order-form-btn"
                    type="submit"
                    disabled={loading === 'create'}
                    className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-colors shadow-xs flex items-center space-x-1.5"
                  >
                    {loading === 'create' ? 'Đang tạo...' : 'Tạo đơn ngay'}
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Orders Table Card */}
        <div id="orders-list-card" className="bg-white border border-zinc-200/80 rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table id="orders-dashboard-table" className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-zinc-50 border-b border-zinc-200 text-[11px] font-bold text-zinc-500 uppercase tracking-wider">
                  <th className="py-3 px-4">Mã Vận Đơn</th>
                  <th className="py-3 px-4">Người Nhận</th>
                  <th className="py-3 px-4">COD / Địa Chỉ</th>
                  <th className="py-3 px-4">Trạng Thái</th>
                  <th className="py-3 px-4 text-center">Thao Tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 text-xs text-zinc-600">
                {filteredOrders.length > 0 ? (
                  filteredOrders.map((order) => {
                    const status = statusConfig[order.status] || { text: order.status, color: 'text-zinc-600', bg: 'bg-zinc-50', dot: 'bg-zinc-400' };
                    const isSelected = selectedOrder?.id === order.id;

                    return (
                      <tr
                        id={`order-row-${order.id}`}
                        key={order.id}
                        onClick={() => setSelectedOrder(order)}
                        className={`hover:bg-zinc-50 cursor-pointer transition-colors duration-150 ${isSelected ? 'bg-indigo-50/40 hover:bg-indigo-50/60' : ''}`}
                      >
                        <td className="py-3.5 px-4">
                          <div className="font-mono font-bold text-zinc-900 tracking-tight flex items-center space-x-1">
                            <span>{order.id}</span>
                            <ChevronRight className="w-3 h-3 text-zinc-400" />
                          </div>
                          <span className="text-[10px] text-zinc-400">
                            {new Date(order.createdAt).toLocaleDateString('vi-VN')}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 font-medium">
                          <div className="text-zinc-900 font-medium">{order.receiverName}</div>
                          <div className="text-[10px] text-zinc-400">{order.receiverPhone}</div>
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-zinc-900">{order.codAmount.toLocaleString('vi-VN')} đ</div>
                          <div className="text-[10px] text-zinc-400 truncate max-w-44">{order.receiverAddress}</div>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full border text-[10px] font-bold ${status.color} ${status.bg}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${status.dot}`} />
                            <span>{status.text}</span>
                          </span>
                        </td>
                        <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-center space-x-2">
                            {/* Simulate Journey Trigger */}
                            {['pending', 'picked', 'shipping'].includes(order.status) && (
                              <button
                                id={`simulate-btn-${order.id}`}
                                title="Mô phỏng hành trình"
                                onClick={(e) => handleSimulate(order.id, e)}
                                disabled={loading === `simulate-${order.id}`}
                                className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg transition-colors border border-amber-200/50"
                              >
                                <Play className="w-3.5 h-3.5 fill-amber-700" />
                              </button>
                            )}

                            {/* Notify Zalo trigger */}
                            <button
                              id={`zalo-notify-btn-${order.id}`}
                              title="Gửi Zalo"
                              onClick={(e) => handleOpenNotificationModal(order, 'zalo', e)}
                              className="p-1.5 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-lg transition-colors border border-sky-200/50"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete order */}
                            <button
                              id={`delete-btn-${order.id}`}
                              title="Xóa đơn"
                              onClick={(e) => handleDelete(order.id, e)}
                              disabled={loading === `delete-${order.id}`}
                              className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-colors border border-red-200/50"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-zinc-400 text-xs">
                      Không tìm thấy đơn hàng nào khớp với bộ lọc
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Details Side-Drawer/Column */}
      <div id="order-detail-column" className="xl:col-span-1">
        <AnimatePresence mode="wait">
          {selectedOrder ? (
            <motion.div
              id="selected-order-detail-card"
              key={selectedOrder.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
              className="bg-white border border-zinc-200/80 rounded-2xl shadow-xs overflow-hidden sticky top-4 flex flex-col"
            >
              {/* Card Header */}
              <div className="p-4 bg-zinc-50 border-b border-zinc-200/60 flex items-center justify-between">
                <div>
                  <div className="text-[10px] uppercase font-bold text-zinc-400">Chi tiết vận đơn</div>
                  <h4 className="font-mono text-base font-bold text-zinc-900">{selectedOrder.id}</h4>
                </div>
                <button
                  id="close-details-btn"
                  onClick={() => setSelectedOrder(null)}
                  className="p-1.5 hover:bg-zinc-200 rounded-lg text-zinc-400"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Order Metadata */}
              <div id="selected-order-details-body" className="p-5 space-y-4 text-xs">
                {/* Status Box */}
                <div className="p-3 bg-zinc-50 border border-zinc-150 rounded-xl space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-zinc-500 uppercase">Trạng thái hiện tại</span>
                    <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${statusConfig[selectedOrder.status].color} ${statusConfig[selectedOrder.status].bg}`}>
                      {statusConfig[selectedOrder.status].text}
                    </span>
                  </div>
                  {/* Simulate next stage button */}
                  {['pending', 'picked', 'shipping'].includes(selectedOrder.status) && (
                    <button
                      id="simulate-next-stage-btn"
                      onClick={(e) => handleSimulate(selectedOrder.id, e)}
                      disabled={loading === `simulate-${selectedOrder.id}`}
                      className="w-full mt-2 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg text-[10px] tracking-wide transition-colors flex items-center justify-center space-x-1"
                    >
                      <Play className="w-3 h-3 fill-white" />
                      <span>{loading === `simulate-${selectedOrder.id}` ? 'Đang chuyển trạng thái...' : 'MÔ PHỎNG TIẾN TRÌNH KẾ TIẾP'}</span>
                    </button>
                  )}
                </div>

                {/* Receiver Info */}
                <div className="space-y-3">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block border-b border-zinc-100 pb-1">
                    Thông tin giao nhận
                  </span>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2 text-zinc-700">
                      <User className="w-3.5 h-3.5 text-zinc-400" />
                      <div>
                        <div className="font-semibold">{selectedOrder.receiverName}</div>
                        <div className="text-[10px] text-zinc-400">Người nhận</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 text-zinc-700">
                      <Phone className="w-3.5 h-3.5 text-zinc-400" />
                      <div>
                        <div>{selectedOrder.receiverPhone}</div>
                        <div className="text-[10px] text-zinc-400">Số điện thoại</div>
                      </div>
                    </div>
                    <div className="flex items-start space-x-2 text-zinc-700">
                      <MapPin className="w-3.5 h-3.5 text-zinc-400 shrink-0 mt-0.5" />
                      <div>
                        <div>{selectedOrder.receiverAddress}</div>
                        <div className="text-[10px] text-zinc-400">Địa chỉ phát</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Logistics Pricing */}
                <div className="grid grid-cols-3 gap-2 bg-zinc-50/50 p-3 rounded-xl border border-zinc-200/50">
                  <div className="text-center">
                    <div className="text-[10px] font-bold text-zinc-400 uppercase">COD Thu Hộ</div>
                    <div className="font-bold text-zinc-900 mt-1">{selectedOrder.codAmount.toLocaleString('vi-VN')}đ</div>
                  </div>
                  <div className="text-center border-x border-zinc-200">
                    <div className="text-[10px] font-bold text-zinc-400 uppercase">Phí Ship</div>
                    <div className="font-bold text-zinc-900 mt-1">{selectedOrder.shippingFee.toLocaleString('vi-VN')}đ</div>
                  </div>
                  <div className="text-center">
                    <div className="text-[10px] font-bold text-zinc-400 uppercase">Khối Lượng</div>
                    <div className="font-bold text-zinc-900 mt-1">{selectedOrder.weight}g</div>
                  </div>
                </div>

                {/* Journey Timeline */}
                <div className="space-y-3">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block border-b border-zinc-100 pb-1">
                    Lịch trình chi tiết (Hành trình)
                  </span>
                  <div id="timeline-flow" className="relative pl-4 space-y-4 border-l-2 border-zinc-200">
                    {selectedOrder.history.map((event, idx) => {
                      const isLast = idx === selectedOrder.history.length - 1;
                      return (
                        <div key={idx} className="relative">
                          <span className={`absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full border-2 border-white ${isLast ? 'bg-indigo-600 ring-4 ring-indigo-100' : 'bg-zinc-400'}`} />
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-semibold text-zinc-400">
                              {new Date(event.time).toLocaleString('vi-VN')}
                            </span>
                            <div className={`font-semibold ${isLast ? 'text-zinc-900 font-bold' : 'text-zinc-600'}`}>
                              {event.description}
                            </div>
                            <span className="text-[10px] text-zinc-500 block">
                              📍 {event.location}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              id="empty-details-card"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-zinc-50 border border-dashed border-zinc-300 rounded-2xl p-8 text-center text-zinc-400 text-xs flex flex-col items-center justify-center space-y-3"
            >
              <HelpCircle className="w-8 h-8 text-zinc-300" />
              <div>
                <p className="font-semibold text-zinc-600 text-sm">Chưa chọn đơn hàng</p>
                <p className="text-zinc-400 mt-1">Nhấp vào một dòng đơn hàng trong danh sách để xem lịch trình bưu tá chi tiết, mô phỏng nâng cao và gửi tin nhắn.</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Manual Notification Send Modal */}
      <AnimatePresence>
        {activeNotifyModal && (
          <div id="notify-overlay-modal" className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              id="notify-modal-card"
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-white rounded-2xl border border-zinc-200 shadow-xl overflow-hidden max-w-lg w-full flex flex-col"
            >
              {/* Modal Header */}
              <div className="p-4 bg-zinc-50 border-b border-zinc-200 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className={`p-1.5 rounded-lg ${activeNotifyModal.channel === 'zalo' ? 'bg-sky-500 text-white' : 'bg-blue-600 text-white'}`}>
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-zinc-900">
                      Gửi thông báo {activeNotifyModal.channel === 'zalo' ? 'Zalo ZNS' : 'Facebook Messenger'}
                    </h4>
                    <p className="text-[10px] text-zinc-400">Đơn hàng {activeNotifyModal.order.id}</p>
                  </div>
                </div>
                <button
                  id="close-notify-modal-btn"
                  onClick={() => setActiveNotifyModal(null)}
                  className="p-1 hover:bg-zinc-200 rounded-lg text-zinc-400"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3 text-xs bg-zinc-50 p-3 rounded-xl border border-zinc-200/50">
                  <div>
                    <div className="text-[10px] text-zinc-400 uppercase font-bold">Người nhận</div>
                    <div className="font-semibold text-zinc-800 mt-0.5">{activeNotifyModal.order.receiverName}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-zinc-400 uppercase font-bold">Thông tin liên hệ</div>
                    <div className="font-semibold text-zinc-800 mt-0.5">{activeNotifyModal.order.receiverPhone}</div>
                  </div>
                </div>

                {/* AI Draft Assist Bar */}
                <div className="bg-indigo-50 border border-indigo-100 p-3 rounded-xl flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
                    <span className="text-[11px] text-indigo-950 font-semibold">Tự động soạn tin nhắn thông minh với Gemini AI</span>
                  </div>
                  <button
                    id="regenerate-ai-draft-btn"
                    onClick={() => handleOpenNotificationModal(activeNotifyModal.order, activeNotifyModal.channel, { stopPropagation: () => {} } as any)}
                    disabled={draftingAI}
                    className="flex items-center space-x-1 text-[10px] text-indigo-600 hover:text-indigo-700 bg-white px-2 py-1 rounded-lg border border-indigo-200 font-bold"
                  >
                    <RefreshCw className={`w-3 h-3 ${draftingAI ? 'animate-spin' : ''}`} />
                    <span>Làm mới mẫu AI</span>
                  </button>
                </div>

                {/* Message Text area */}
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-600 uppercase">Nội dung tin nhắn gửi đi</label>
                  {draftingAI ? (
                    <div className="w-full h-24 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-center text-xs text-zinc-400 space-x-2">
                      <Sparkles className="w-4 h-4 animate-spin text-indigo-500" />
                      <span>Gemini AI đang soạn tin nhắn tối ưu...</span>
                    </div>
                  ) : (
                    <textarea
                      id="notify-message-textarea"
                      rows={4}
                      className="w-full px-3 py-2 border border-zinc-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 resize-none font-medium text-zinc-700"
                      value={notifyDraft}
                      onChange={(e) => setNotifyDraft(e.target.value)}
                    />
                  )}
                </div>

                {activeNotifyModal.channel === 'zalo' && (
                  <div className="bg-sky-50 border border-sky-100 p-3 rounded-xl space-y-2">
                    <span className="font-bold text-sky-800 text-[10px] block uppercase tracking-wider">
                      Lựa chọn kênh gửi Zalo:
                    </span>
                    <div className="grid grid-cols-2 gap-3 text-[11px]">
                      <button
                        type="button"
                        onClick={handleSendViaPersonalZalo}
                        disabled={draftingAI || !notifyDraft}
                        className="p-3 bg-white border border-sky-200 rounded-xl hover:bg-sky-100/50 hover:border-sky-300 transition-all flex flex-col items-center text-center text-zinc-700 shadow-2xs group"
                      >
                        <span className="font-bold text-sky-700 flex items-center gap-1 group-hover:scale-105 transition-transform">
                          💬 Zalo Số Cá Nhân (Miễn phí)
                        </span>
                        <span className="text-[9px] text-zinc-500 mt-1 leading-relaxed">Mở zalo.me chat riêng và tự động copy nội dung</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleSendNotification}
                        disabled={loading === 'send-notification' || draftingAI || !notifyDraft}
                        className="p-3 bg-white border border-indigo-200 rounded-xl hover:bg-indigo-50 transition-all flex flex-col items-center text-center text-zinc-700 shadow-2xs group"
                      >
                        <span className="font-bold text-indigo-700 flex items-center gap-1 group-hover:scale-105 transition-transform">
                          🏢 Zalo ZNS (Doanh nghiệp)
                        </span>
                        <span className="text-[9px] text-zinc-500 mt-1 leading-relaxed">Gửi tự động qua API OA (Cần cấu hình token)</span>
                      </button>
                    </div>
                  </div>
                )}

                {personalZaloCopied && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-950 rounded-xl text-xs space-y-1.5"
                  >
                    <div className="flex items-center space-x-1.5 font-bold text-emerald-800">
                      <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                      <span>Đã copy nội dung và mở chat Zalo thành công!</span>
                    </div>
                    <p className="text-[11px] text-zinc-600 leading-relaxed">
                      Cửa sổ trò chuyện với số điện thoại <strong>{activeNotifyModal.order.receiverPhone}</strong> đã được mở trong tab mới. Hãy nhấn <strong>Ctrl + V</strong> (hoặc nhấn giữ chọn Dán) để gửi tin nhắn ngay lập tức.
                    </p>
                  </motion.div>
                )}

                {/* Send action result analysis */}
                {sendResult && (
                  <div className={`p-4 rounded-xl border text-xs space-y-2 ${sendResult.success ? 'bg-emerald-50 border-emerald-100 text-emerald-950' : 'bg-red-50 border-red-100 text-red-950'}`}>
                    <div className="flex items-center space-x-2 font-bold">
                      {sendResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-red-600" />}
                      <span>{sendResult.log.status === 'simulated' ? 'Đã kích hoạt API (Gia Lập)' : 'Kích hoạt API Thành Công!'}</span>
                    </div>
                    <p className="text-[11px] text-zinc-600">Đơn vận {orderIdAndStatusFormat(activeNotifyModal.order)}. Log ID: {sendResult.log.id}</p>

                    {/* Developer JSON Debug Panel */}
                    <div className="mt-2 text-[10px] font-mono bg-zinc-900 text-zinc-200 p-2.5 rounded-lg overflow-x-auto max-h-36">
                      <div className="text-zinc-400 mb-1 border-b border-zinc-800 pb-1 flex justify-between items-center">
                        <span>OUTGOING API PAYLOAD DETAILS</span>
                        <span className="bg-zinc-800 px-1 py-0.5 rounded text-[9px]">JSON</span>
                      </div>
                      {sendResult.log.payload}
                    </div>
                  </div>
                )}
              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-zinc-50 border-t border-zinc-200/80 flex justify-end space-x-2">
                <button
                  id="cancel-notify-modal-btn"
                  onClick={() => setActiveNotifyModal(null)}
                  className="px-4 py-2 border border-zinc-200 rounded-xl text-xs font-semibold text-zinc-600 hover:bg-zinc-50 transition-colors"
                >
                  Đóng lại
                </button>
                <button
                  id="send-notify-action-btn"
                  onClick={handleSendNotification}
                  disabled={loading === 'send-notification' || draftingAI || !notifyDraft}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-xs flex items-center space-x-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{loading === 'send-notification' ? 'Đang gọi API...' : 'KÍCH HOẠT API GỬI'}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function orderIdAndStatusFormat(order: Order): string {
  return `${order.id} [${order.status.toUpperCase()}]`;
}
