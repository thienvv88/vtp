import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { NotificationConfig, NotificationLog, OrderStatus } from '../types';
import {
  Save,
  MessageSquare,
  Facebook,
  Bot,
  Terminal,
  Settings2,
  BellRing,
  Clock,
  CheckCircle2,
  AlertCircle,
  Eye,
  X,
  Code,
  Truck,
  Key
} from 'lucide-react';

interface NotificationSettingsProps {
  config: NotificationConfig;
  logs: NotificationLog[];
  onSaveConfig: (newConfig: NotificationConfig) => Promise<void>;
}

export default function NotificationSettings({ config, logs, onSaveConfig }: NotificationSettingsProps) {
  // Config state
  const [zaloEnabled, setZaloEnabled] = useState(config.zaloEnabled);
  const [zaloToken, setZaloToken] = useState(config.zaloToken);
  const [zaloOaId, setZaloOaId] = useState(config.zaloOaId);
  const [zaloTemplateId, setZaloTemplateId] = useState(config.zaloTemplateId);

  const [fbEnabled, setFbEnabled] = useState(config.fbEnabled);
  const [fbToken, setFbToken] = useState(config.fbToken);
  const [fbPageId, setFbPageId] = useState(config.fbPageId);

  const [autoNotifyOnStatus, setAutoNotifyOnStatus] = useState<OrderStatus[]>(config.autoNotifyOnStatus);

  // Viettel Post integration state
  const [vtpEnabled, setVtpEnabled] = useState(config.vtpEnabled ?? false);
  const [vtpToken, setVtpToken] = useState(config.vtpToken ?? '');
  const [vtpUsername, setVtpUsername] = useState(config.vtpUsername ?? '');
  const [vtpPassword, setVtpPassword] = useState(config.vtpPassword ?? '');
  const [vtpShopId, setVtpShopId] = useState(config.vtpShopId ?? '');

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [selectedLog, setSelectedLog] = useState<NotificationLog | null>(null);

  const handleStatusToggle = (status: OrderStatus) => {
    if (autoNotifyOnStatus.includes(status)) {
      setAutoNotifyOnStatus(autoNotifyOnStatus.filter((s) => s !== status));
    } else {
      setAutoNotifyOnStatus([...autoNotifyOnStatus, status]);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveSuccess(false);
    try {
      await onSaveConfig({
        zaloEnabled,
        zaloToken,
        zaloOaId,
        zaloTemplateId,
        fbEnabled,
        fbToken,
        fbPageId,
        autoNotifyOnStatus,
        vtpEnabled,
        vtpToken,
        vtpUsername,
        vtpPassword,
        vtpShopId,
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const statusLabelMap: Record<OrderStatus, string> = {
    pending: 'Khởi tạo bưu gửi (Chờ lấy)',
    picked: 'Bưu tá thu gom (Đã lấy hàng)',
    shipping: 'Hàng xuất kho vận chuyển (Đang giao)',
    delivered: 'Giao hàng thành công (Ký nhận)',
    returned: 'Người nhận từ chối (Chuyển hoàn)',
    cancelled: 'Hủy đơn hàng',
  };

  return (
    <div id="notification-settings-section" className="space-y-6">
      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Settings column 1 & 2 */}
        <div id="config-settings-main-column" className="lg:col-span-2 space-y-6">
          {/* Viettel Post Connection Panel */}
          <motion.div
            id="vtp-api-config-card"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border border-red-200/60 shadow-xs rounded-2xl p-5 space-y-4 animate-fade-in"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-red-50 text-red-600 rounded-xl">
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-zinc-900 flex items-center gap-1.5">
                    Tích hợp Viettel Post OpenAPI
                    <span className="px-2 py-0.5 bg-red-50 text-red-600 text-[9px] rounded-md font-bold uppercase tracking-wider">
                      Official
                    </span>
                  </h4>
                  <p className="text-xs text-zinc-500">Đồng bộ vận đơn, trạng thái bưu cục từ tài khoản Viettel Post cá nhân</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  id="checkbox-vtp-enabled"
                  type="checkbox"
                  className="sr-only peer"
                  checked={vtpEnabled}
                  onChange={(e) => setVtpEnabled(e.target.checked)}
                />
                <div className="w-9 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-600"></div>
              </label>
            </div>

            {vtpEnabled && (
              <div id="vtp-form-fields" className="space-y-4 text-xs">
                <div className="bg-red-50/50 rounded-xl p-3 border border-red-100/80 space-y-1.5">
                  <span className="font-bold text-red-800 text-[10px] block uppercase tracking-wider">Hướng dẫn lấy thông tin API:</span>
                  <p className="text-[11px] text-zinc-600 leading-relaxed">
                    1. Truy cập cổng đối tác: <a href="https://partner.viettelpost.vn/" target="_blank" rel="noreferrer" className="text-red-600 font-semibold underline hover:text-red-700">partner.viettelpost.vn</a> và đăng nhập.
                    <br />
                    2. Vào mục <strong>Cấu hình API</strong> hoặc <strong>Quản lý Token</strong>.
                    <br />
                    3. Sao chép <strong>Partner Token</strong> và dán vào ô bên dưới. Hoặc điền tài khoản & mật khẩu Viettel Post để hệ thống tự động xác thực lấy token khi cần.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2 space-y-1">
                    <label className="font-bold text-zinc-600 uppercase text-[10px] flex items-center gap-1">
                      <Key className="w-3 h-3 text-zinc-400" /> Partner Token (API Token)
                    </label>
                    <input
                      id="input-vtp-token"
                      type="password"
                      placeholder="Dán Viettel Post Partner Token..."
                      className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                      value={vtpToken}
                      onChange={(e) => setVtpToken(e.target.value)}
                    />
                    <p className="text-[10px] text-zinc-400">Nếu có Partner Token, bạn không cần nhập thông tin tài khoản đăng nhập bên dưới.</p>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-zinc-600 uppercase text-[10px]">Tài khoản Viettel Post (Username/SĐT)</label>
                    <input
                      id="input-vtp-username"
                      type="text"
                      placeholder="090xxxxxxx hoặc email..."
                      className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                      value={vtpUsername}
                      onChange={(e) => setVtpUsername(e.target.value)}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-zinc-600 uppercase text-[10px]">Mật khẩu tài khoản</label>
                    <input
                      id="input-vtp-password"
                      type="password"
                      placeholder="••••••••"
                      className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                      value={vtpPassword}
                      onChange={(e) => setVtpPassword(e.target.value)}
                    />
                  </div>

                  <div className="md:col-span-2 space-y-1">
                    <label className="font-bold text-zinc-600 uppercase text-[10px]">Mã Cửa Hàng / Shop ID (Không bắt buộc)</label>
                    <input
                      id="input-vtp-shopid"
                      type="text"
                      placeholder="Ví dụ: 824159 (Mặc định sẽ lấy bưu cục chính)"
                      className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                      value={vtpShopId}
                      onChange={(e) => setVtpShopId(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}
          </motion.div>

          {/* Zalo Configuration Panel */}
          <motion.div
            id="zalo-api-config-card"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border border-zinc-200/85 shadow-xs rounded-2xl p-5 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-sky-50 text-sky-600 rounded-xl">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-zinc-900">Tích hợp API Zalo Notification Service (ZNS)</h4>
                  <p className="text-xs text-zinc-500">Gửi thông báo bưu cục chính thức tới số điện thoại khách hàng</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  id="checkbox-zalo-enabled"
                  type="checkbox"
                  className="sr-only peer"
                  checked={zaloEnabled}
                  onChange={(e) => setZaloEnabled(e.target.checked)}
                />
                <div className="w-9 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-sky-500"></div>
              </label>
            </div>

            {zaloEnabled && (
              <div id="zalo-form-fields" className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="md:col-span-2 space-y-1">
                  <label className="font-bold text-zinc-600 uppercase text-[10px]">Zalo OA Access Token</label>
                  <input
                    id="input-zalo-token"
                    type="password"
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.zalo..."
                    className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    value={zaloToken}
                    onChange={(e) => setZaloToken(e.target.value)}
                  />
                  <p className="text-[10px] text-zinc-400">Yêu cầu quyền gửi tin nhắn OA và ZNS của Zalo Developers</p>
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-zinc-600 uppercase text-[10px]">Zalo Official Account ID (OA ID)</label>
                  <input
                    id="input-zalo-oa-id"
                    type="text"
                    placeholder="182940251920"
                    className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    value={zaloOaId}
                    onChange={(e) => setZaloOaId(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-zinc-600 uppercase text-[10px]">Mã Mẫu ZNS (Template ID)</label>
                  <input
                    id="input-zalo-template-id"
                    type="text"
                    placeholder="293019"
                    className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                    value={zaloTemplateId}
                    onChange={(e) => setZaloTemplateId(e.target.value)}
                  />
                </div>
              </div>
            )}
          </motion.div>

          {/* FB Configuration Panel */}
          <motion.div
            id="fb-api-config-card"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border border-zinc-200/85 shadow-xs rounded-2xl p-5 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                  <Facebook className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-zinc-900">Tích hợp Facebook Messenger API</h4>
                  <p className="text-xs text-zinc-500">Gửi cảnh báo và thông tin chăm sóc khách hàng tự động qua inbox fanpage</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  id="checkbox-fb-enabled"
                  type="checkbox"
                  className="sr-only peer"
                  checked={fbEnabled}
                  onChange={(e) => setFbEnabled(e.target.checked)}
                />
                <div className="w-9 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {fbEnabled && (
              <div id="fb-form-fields" className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="md:col-span-2 space-y-1">
                  <label className="font-bold text-zinc-600 uppercase text-[10px]">Page Access Token</label>
                  <input
                    id="input-fb-token"
                    type="password"
                    placeholder="EAAKk9ZBZDZD..."
                    className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    value={fbToken}
                    onChange={(e) => setFbToken(e.target.value)}
                  />
                  <p className="text-[10px] text-zinc-400">Token phát hành từ Meta App Developers với quyền pages_messaging</p>
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-zinc-600 uppercase text-[10px]">Facebook Page ID (ID Trang)</label>
                  <input
                    id="input-fb-page-id"
                    type="text"
                    placeholder="102941058192"
                    className="w-full px-3 py-2 border border-zinc-250 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    value={fbPageId}
                    onChange={(e) => setFbPageId(e.target.value)}
                  />
                </div>
              </div>
            )}
          </motion.div>
        </div>

        {/* Trigger Column 3 */}
        <div id="automation-triggers-column" className="space-y-6">
          <motion.div
            id="triggers-card"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border border-zinc-200/85 shadow-xs rounded-2xl p-5 space-y-4"
          >
            <div className="flex items-center space-x-2 border-b border-zinc-100 pb-3 text-zinc-800">
              <Settings2 className="w-4 h-4 text-indigo-600" />
              <h4 className="font-semibold text-sm">Cấu Hình Gửi Tự Động</h4>
            </div>

            <div id="triggers-list" className="space-y-3.5 text-xs text-zinc-600">
              <p className="text-[11px] text-zinc-500">Chọn các bước hành trình mà hệ thống sẽ tự động gửi tin nhắn cho khách hàng:</p>

              {(Object.keys(statusLabelMap) as OrderStatus[]).map((status) => {
                const checked = autoNotifyOnStatus.includes(status);
                return (
                  <label
                    id={`trigger-label-${status}`}
                    key={status}
                    className="flex items-start space-x-3 p-2.5 rounded-xl border border-zinc-100 hover:bg-zinc-50 cursor-pointer transition-colors"
                  >
                    <input
                      id={`checkbox-trigger-${status}`}
                      type="checkbox"
                      className="mt-0.5 rounded border-zinc-300 text-indigo-600 focus:ring-indigo-500/20"
                      checked={checked}
                      onChange={() => handleStatusToggle(status)}
                    />
                    <div>
                      <span className="font-semibold text-zinc-800 block leading-tight">{statusLabelMap[status]}</span>
                      <span className="text-[10px] text-zinc-400 mt-0.5 block">Trigger on '{status}'</span>
                    </div>
                  </label>
                );
              })}
            </div>

            <div className="pt-4 border-t border-zinc-100 flex flex-col space-y-2">
              <button
                id="save-notify-config-btn"
                type="submit"
                disabled={saving}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all duration-150 flex items-center justify-center space-x-1.5"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Đang lưu trữ...' : 'LƯU THIẾT LẬP'}</span>
              </button>

              {saveSuccess && (
                <div id="save-success-banner" className="text-center text-xs font-bold text-emerald-600 bg-emerald-50 py-1.5 rounded-lg border border-emerald-100 animate-pulse">
                  Đã lưu cấu hình API thành công!
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </form>

      {/* API Logs & Developer Panel */}
      <motion.div
        id="api-logs-panel-card"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-white border border-zinc-200/85 rounded-2xl p-5 shadow-xs"
      >
        <div className="flex items-center justify-between border-b border-zinc-100 pb-3 mb-4">
          <div className="flex items-center space-x-2.5">
            <div className="p-1.5 bg-zinc-100 text-zinc-700 rounded-lg">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-zinc-900">Nhật Ký Tích Hợp API Gửi Thông Báo</h4>
              <p className="text-xs text-zinc-500">Giám sát vết JSON payload chi tiết giữa máy chủ và các cổng API Zalo/FB</p>
            </div>
          </div>
          <span className="text-[10px] uppercase font-mono bg-zinc-100 text-zinc-600 px-2.5 py-1 rounded-md font-bold">
            REST API LOGGER
          </span>
        </div>

        <div id="logs-table-wrapper" className="overflow-x-auto">
          <table id="api-logs-table" className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-zinc-50 border-b border-zinc-150 text-[10px] font-bold text-zinc-500 uppercase tracking-wider">
                <th className="py-2.5 px-3">Thời gian</th>
                <th className="py-2.5 px-3">Mã Đơn</th>
                <th className="py-2.5 px-3">Khách Hàng</th>
                <th className="py-2.5 px-3">Cổng Gửi</th>
                <th className="py-2.5 px-3">Nội Dung</th>
                <th className="py-2.5 px-3">Trạng Thái</th>
                <th className="py-2.5 px-3 text-center">API Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 text-xs text-zinc-600">
              {logs.length > 0 ? (
                logs.map((log) => {
                  const isSimulated = log.status === 'simulated';
                  const isSuccess = log.status === 'success';

                  return (
                    <tr id={`log-row-${log.id}`} key={log.id} className="hover:bg-zinc-50/50">
                      <td className="py-3 px-3 font-mono text-[10px] text-zinc-400 whitespace-nowrap">
                        {new Date(log.sentAt).toLocaleString('vi-VN')}
                      </td>
                      <td className="py-3 px-3 font-bold font-mono text-zinc-900">{log.orderId}</td>
                      <td className="py-3 px-3 font-medium truncate max-w-36">{log.recipient}</td>
                      <td className="py-3 px-3">
                        <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${log.channel === 'zalo' ? 'bg-sky-50 text-sky-700 border border-sky-100' : 'bg-blue-50 text-blue-700 border border-blue-100'}`}>
                          {log.channel === 'zalo' ? 'Zalo ZNS' : 'Messenger'}
                        </span>
                      </td>
                      <td className="py-3 px-3 max-w-48 truncate">{log.message}</td>
                      <td className="py-3 px-3">
                        <span className={`inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold ${isSimulated ? 'bg-amber-50 text-amber-700 border border-amber-200' : isSuccess ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
                          <span className={`w-1 h-1 rounded-full ${isSimulated ? 'bg-amber-500' : isSuccess ? 'bg-emerald-500' : 'bg-red-500'}`} />
                          <span>{isSimulated ? 'Simulated' : isSuccess ? 'Success' : 'Failed'}</span>
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          id={`view-log-payload-btn-${log.id}`}
                          onClick={() => setSelectedLog(log)}
                          className="p-1 text-zinc-400 hover:text-indigo-600 rounded-lg hover:bg-zinc-100 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-zinc-400 text-xs">
                    Chưa có nhật ký gửi API nào được khởi tạo.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Log Payload JSON Drawer Modal */}
      <AnimatePresence>
        {selectedLog && (
          <div id="payload-drawer-overlay" className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              id="payload-drawer-card"
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-zinc-950 text-zinc-200 border border-zinc-800 rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden flex flex-col h-[500px]"
            >
              {/* Header */}
              <div className="p-4 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <Code className="w-4 h-4 text-emerald-400" />
                  <div>
                    <h4 className="font-semibold text-xs text-white">API TRANSACTION PAYLOAD VIEWER</h4>
                    <p className="text-[10px] text-zinc-500">Log ID: {selectedLog.id} • Order: {selectedLog.orderId}</p>
                  </div>
                </div>
                <button
                  id="close-payload-drawer-btn"
                  onClick={() => setSelectedLog(null)}
                  className="p-1 hover:bg-zinc-800 rounded-lg text-zinc-400"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Code Area */}
              <div id="payload-code-area" className="flex-1 p-5 overflow-y-auto font-mono text-[10px] leading-relaxed">
                <div className="space-y-4">
                  <div>
                    <span className="text-zinc-500 font-bold block mb-1 uppercase text-[9px]">// Giao dịch và thông tin cơ bản</span>
                    <table className="w-full text-[10px] text-zinc-400">
                      <tbody>
                        <tr><td className="py-0.5 text-zinc-500 w-24">Thời gian:</td><td>{selectedLog.sentAt}</td></tr>
                        <tr><td className="py-0.5 text-zinc-500">Số nhận:</td><td>{selectedLog.recipient}</td></tr>
                        <tr><td className="py-0.5 text-zinc-500">Kênh phát:</td><td>{selectedLog.channel.toUpperCase()}</td></tr>
                        <tr><td className="py-0.5 text-zinc-500">Nội dung tin:</td><td className="text-zinc-300">{selectedLog.message}</td></tr>
                      </tbody>
                    </table>
                  </div>

                  <div>
                    <span className="text-emerald-400 font-bold block mb-1 uppercase text-[9px]">// CHI TIẾT REQUEST & RESPONSE PAYLOAD</span>
                    <pre className="p-3 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-300 overflow-x-auto whitespace-pre-wrap">
                      {selectedLog.payload}
                    </pre>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-3.5 bg-zinc-900 border-t border-zinc-800/80 flex justify-end">
                <button
                  id="close-payload-drawer-footer-btn"
                  onClick={() => setSelectedLog(null)}
                  className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-[10px] rounded-lg transition-colors border border-zinc-700/60"
                >
                  Đóng lại
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
