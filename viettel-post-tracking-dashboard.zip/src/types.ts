export type OrderStatus = 'pending' | 'picked' | 'shipping' | 'delivered' | 'returned' | 'cancelled';

export interface HistoryEvent {
  time: string;
  location: string;
  description: string;
  status: OrderStatus;
}

export interface Order {
  id: string; // Viettel Post tracking code
  senderName: string;
  senderPhone: string;
  receiverName: string;
  receiverPhone: string;
  receiverAddress: string;
  codAmount: number;
  shippingFee: number;
  weight: number; // in grams
  status: OrderStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
  history: HistoryEvent[];
}

export interface NotificationConfig {
  zaloEnabled: boolean;
  zaloToken: string;
  zaloOaId: string;
  zaloTemplateId: string;
  fbEnabled: boolean;
  fbToken: string;
  fbPageId: string;
  autoNotifyOnStatus: OrderStatus[];
  vtpEnabled?: boolean;
  vtpToken?: string;
  vtpUsername?: string;
  vtpPassword?: string;
  vtpShopId?: string;
}

export interface NotificationLog {
  id: string;
  orderId: string;
  recipient: string;
  channel: 'zalo' | 'facebook';
  status: 'success' | 'failed' | 'simulated';
  sentAt: string;
  message: string;
  payload: string; // JSON payload details for transparency
}

export interface DashboardStats {
  totalOrders: number;
  pendingCount: number;
  pickedCount: number;
  shippingCount: number;
  deliveredCount: number;
  returnedCount: number;
  cancelledCount: number;
  totalCOD: number;
  totalShippingFee: number;
  successRate: number; // Delivered / Total (excluding pending/cancelled)
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
}
