import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Order, NotificationConfig, NotificationLog, ChatMessage } from './types';
import StatsDashboard from './components/StatsDashboard';
import OrderList from './components/OrderList';
import NotificationSettings from './components/NotificationSettings';
import AIChatBot from './components/AIChatBot';
import {
  LayoutDashboard,
  PackageCheck,
  Radio,
  Sparkles,
  RefreshCw,
  Clock,
  ShieldCheck,
  AlertCircle,
  Truck
} from 'lucide-react';

export default function App() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [config, setConfig] = useState<NotificationConfig | null>(null);
  const [logs, setLogs] = useState<NotificationLog[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'orders' | 'settings' | 'ai-assistant'>('dashboard');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [syncingVTP, setSyncingVTP] = useState(false);

  // Fetch all initial data
  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [ordersRes, configRes, logsRes] = await Promise.all([
        fetch('/api/orders'),
        fetch('/api/notify/config'),
        fetch('/api/notify/logs')
      ]);

      if (!ordersRes.ok || !configRes.ok || !logsRes.ok) {
        throw new Error('Không thể tải dữ liệu từ máy chủ. Vui lòng kiểm tra lại trạng thái server.');
      }

      const ordersData = await ordersRes.json();
      const configData = await configRes.json();
      const logsData = await logsRes.json();

      setOrders(ordersData);
      setConfig(configData);
      setLogs(logsData);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Lỗi kết nối bưu cục.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // API Callbacks passed to components
  const handleAddOrder = async (orderData: any) => {
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      if (!res.ok) throw new Error('Không thể khởi tạo đơn hàng.');
      const newOrder = await res.json();
      setOrders((prev) => [newOrder, ...prev]);
      // Refetch logs to update automatic trigger audits
      const logsRes = await fetch('/api/notify/logs');
      if (logsRes.ok) {
        const logsData = await logsRes.json();
        setLogs(logsData);
      }
    } catch (err) {
      console.error(err);
      alert('Tạo đơn hàng thất bại.');
    }
  };

  const handleDeleteOrder = async (id: string) => {
    try {
      const res = await fetch(`/api/orders/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Không thể xóa đơn hàng.');
      setOrders((prev) => prev.filter((o) => o.id !== id));
    } catch (err) {
      console.error(err);
      alert('Xóa đơn hàng thất bại.');
    }
  };

  const handleSimulateOrder = async (id: string) => {
    try {
      const res = await fetch(`/api/orders/${id}/simulate`, { method: 'POST' });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Mô phỏng thất bại.');
      }
      const data = await res.json();

      // Update orders list local state
      setOrders((prev) =>
        prev.map((o) => (o.id === id ? data.order : o))
      );

      // Refetch logs because the status transition may have triggered an auto-notification!
      const logsRes = await fetch('/api/notify/logs');
      if (logsRes.ok) {
        const logsData = await logsRes.json();
        setLogs(logsData);
      }
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Mô phỏng hành trình thất bại.');
    }
  };

  const handleUpdateOrder = async (id: string, updateData: any) => {
    try {
      const res = await fetch(`/api/orders/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData)
      });
      if (!res.ok) throw new Error('Không thể cập nhật đơn hàng.');
      const updatedOrder = await res.json();
      setOrders((prev) =>
        prev.map((o) => (o.id === id ? updatedOrder : o))
      );
    } catch (err) {
      console.error(err);
      alert('Cập nhật trạng thái thất bại.');
    }
  };

  const handleSaveConfig = async (newConfig: NotificationConfig) => {
    try {
      const res = await fetch('/api/notify/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newConfig)
      });
      if (!res.ok) throw new Error('Lỗi lưu cấu hình.');
      const data = await res.json();
      setConfig(data.config);
    } catch (err) {
      console.error(err);
      alert('Không thể lưu cấu hình API.');
    }
  };

  const handleSyncViettelPost = async () => {
    setSyncingVTP(true);
    try {
      const res = await fetch('/api/vtpost/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Đồng bộ thất bại.');
      }
      
      // Update local orders list state
      const ordersRes = await fetch('/api/orders');
      if (ordersRes.ok) {
        const ordersData = await ordersRes.json();
        setOrders(ordersData);
      }

      alert(data.message || 'Đồng bộ đơn hàng Viettel Post thành công!');
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Lỗi đồng bộ Viettel Post.');
    } finally {
      setSyncingVTP(false);
    }
  };

  const handleDraftNotification = async (orderId: string, channel: 'zalo' | 'facebook'): Promise<string> => {
    try {
      const res = await fetch('/api/ai/draft-notification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, channel })
      });
      if (!res.ok) throw new Error('Lỗi soạn tin nhắn.');
      const data = await res.json();
      return data.draft;
    } catch (err) {
      console.error(err);
      return 'Lỗi khi soạn tin nhắn mẫu tự động.';
    }
  };

  const handleSendNotification = async (orderId: string, channel: 'zalo' | 'facebook', recipient: string, message: string) => {
    try {
      const res = await fetch('/api/notify/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, channel, recipient, message })
      });
      if (!res.ok) throw new Error('Lỗi kích hoạt gửi tin.');
      const data = await res.json();

      // Refresh logs
      const logsRes = await fetch('/api/notify/logs');
      if (logsRes.ok) {
        const logsData = await logsRes.json();
        setLogs(logsData);
      }

      return data;
    } catch (err) {
      console.error(err);
      alert('Kích hoạt API gửi thất bại.');
      return { success: false };
    }
  };

  const handleSendMessageToAI = async (chatHistory: ChatMessage[]): Promise<string> => {
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: chatHistory })
      });
      if (!res.ok) throw new Error('Lỗi liên lạc trợ lý ảo.');
      const data = await res.json();
      return data.reply;
    } catch (err) {
      console.error(err);
      return 'Tôi tạm thời gặp sự cố khi kết nối cơ sở dữ liệu bưu bục.';
    }
  };

  return (
    <div id="application-layout" className="min-h-screen bg-zinc-50 text-zinc-900 flex flex-col font-sans selection:bg-indigo-500/10 selection:text-indigo-600">
      {/* Brand Header */}
      <header id="app-header-container" className="bg-white border-b border-zinc-200/80 sticky top-0 z-30 shadow-xs px-4 sm:px-6 py-3.5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3.5">
          {/* Custom Viettel Post Logo Block */}
          <div className="px-3 py-1.5 bg-red-600 rounded-lg text-white font-black text-sm tracking-tighter shadow-md select-none transform hover:scale-105 transition-transform duration-200">
            VTPost
          </div>
          <div className="h-6 w-[1.5px] bg-zinc-200 hidden sm:block" />
          <div className="text-center sm:text-left">
            <h1 className="font-bold text-zinc-900 text-sm tracking-tight flex items-center justify-center sm:justify-start">
              <span>Hệ Thống Theo Dõi Đơn Hàng Viettel Post</span>
              <span className="ml-2 px-2 py-0.5 bg-indigo-50 text-indigo-600 text-[10px] rounded-full border border-indigo-100 font-bold hidden md:inline-flex items-center">
                <ShieldCheck className="w-3 h-3 mr-1" />
                API Hub Tích Hợp
              </span>
            </h1>
            <p className="text-[11px] text-zinc-400 mt-0.5">Quản lý hành trình bưu cục, báo cáo tổng quan và gửi tin zalo/facebook tự động</p>
          </div>
        </div>

        {/* Global actions */}
        <div id="global-sync-action" className="flex items-center space-x-2.5 text-xs">
          <button
            id="global-vtp-sync-btn"
            onClick={handleSyncViettelPost}
            disabled={syncingVTP}
            className={`flex items-center space-x-1.5 px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold transition-all shadow-xs ${syncingVTP ? 'opacity-85' : ''}`}
          >
            <Truck className={`w-3.5 h-3.5 ${syncingVTP ? 'animate-bounce' : ''}`} />
            <span>{syncingVTP ? 'Đang đồng bộ...' : 'Đồng bộ Viettel Post'}</span>
          </button>

          <button
            id="global-sync-data-btn"
            onClick={fetchData}
            disabled={loading}
            className="flex items-center space-x-1.5 px-3 py-1.5 border border-zinc-200 hover:bg-zinc-50 text-zinc-600 rounded-xl font-bold transition-all bg-white"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Tải lại</span>
          </button>
        </div>
      </header>

      {/* Navigation Tab Bar */}
      <nav id="navigation-tabs-container" className="bg-white border-b border-zinc-200/60 px-4 sm:px-6 py-2 shrink-0 flex space-x-1 overflow-x-auto scrollbar-none">
        <button
          id="tab-dashboard"
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center space-x-1.5 px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow-xs' : 'text-zinc-600 hover:bg-zinc-50 hover:text-zinc-900'}`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Báo cáo tổng quan</span>
        </button>

        <button
          id="tab-orders"
          onClick={() => setActiveTab('orders')}
          className={`flex items-center space-x-1.5 px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'orders' ? 'bg-indigo-600 text-white shadow-xs' : 'text-zinc-600 hover:bg-zinc-50 hover:text-zinc-900'}`}
        >
          <PackageCheck className="w-4 h-4" />
          <span>Quản lý & Theo dõi đơn</span>
        </button>

        <button
          id="tab-settings"
          onClick={() => setActiveTab('settings')}
          className={`flex items-center space-x-1.5 px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'settings' ? 'bg-indigo-600 text-white shadow-xs' : 'text-zinc-600 hover:bg-zinc-50 hover:text-zinc-900'}`}
        >
          <Radio className="w-4 h-4" />
          <span>Cấu hình API & Logs</span>
        </button>

        <button
          id="tab-ai"
          onClick={() => setActiveTab('ai-assistant')}
          className={`flex items-center space-x-1.5 px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'ai-assistant' ? 'bg-indigo-600 text-white shadow-xs' : 'text-zinc-600 hover:bg-zinc-50 hover:text-zinc-900'}`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Trợ lý ảo PostAI</span>
        </button>
      </nav>

      {/* Main Content Area */}
      <main id="main-content-scroll" className="flex-1 p-4 sm:p-6 overflow-y-auto">
        {loading && orders.length === 0 ? (
          <div id="global-loading-indicator" className="h-72 flex flex-col items-center justify-center space-y-3">
            <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
            <p className="text-xs text-zinc-400 font-semibold">Đang liên kết tới cơ sở dữ liệu bưu cục...</p>
          </div>
        ) : error ? (
          <div id="global-error-indicator" className="bg-red-50 border border-red-200 text-red-950 p-5 rounded-2xl max-w-xl mx-auto space-y-3 shadow-xs">
            <div className="flex items-center space-x-2 font-bold text-sm text-red-700">
              <AlertCircle className="w-5 h-5" />
              <span>Gặp sự cố kết nối máy chủ</span>
            </div>
            <p className="text-xs text-zinc-600">{error}</p>
            <button
              id="retry-fetch-data-btn"
              onClick={fetchData}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
            >
              Thử kết nối lại
            </button>
          </div>
        ) : (
          <div id="tab-content-render" className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && (
              <StatsDashboard orders={orders} />
            )}

            {activeTab === 'orders' && (
              <OrderList
                orders={orders}
                onAddOrder={handleAddOrder}
                onDeleteOrder={handleDeleteOrder}
                onSimulateOrder={handleSimulateOrder}
                onUpdateOrder={handleUpdateOrder}
                onDraftNotification={handleDraftNotification}
                onSendNotification={handleSendNotification}
                onSyncViettelPost={handleSyncViettelPost}
                syncingVTP={syncingVTP}
              />
            )}

            {activeTab === 'settings' && config && (
              <NotificationSettings
                config={config}
                logs={logs}
                onSaveConfig={handleSaveConfig}
              />
            )}

            {activeTab === 'ai-assistant' && (
              <div className="max-w-2xl mx-auto">
                <AIChatBot onSendMessage={handleSendMessageToAI} />
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer bar */}
      <footer id="app-footer-bar" className="bg-white border-t border-zinc-200/60 p-4 text-center text-[10px] text-zinc-400 font-medium tracking-wide flex flex-col sm:flex-row items-center justify-between gap-2 shrink-0">
        <div>
          <span>© 2026 Viettel Post Tracking & API Hub. Đồng bộ hạ tầng bưu chính thông minh.</span>
        </div>
        <div className="flex items-center space-x-3">
          <span className="flex items-center text-emerald-600">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-1.5 animate-pulse" />
            Đồng bộ Cloud Run Container
          </span>
          <span className="text-zinc-300">|</span>
          <span className="text-zinc-500 flex items-center">
            <Clock className="w-3 h-3 mr-1" />
            UTC 2026-06-27
          </span>
        </div>
      </footer>
    </div>
  );
}
